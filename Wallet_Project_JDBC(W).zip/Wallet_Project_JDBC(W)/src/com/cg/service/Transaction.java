package com.cg.service;

import com.cg.bean.Account;
import com.cg.exception.InsufficientFundException;

public interface Transaction  {
	public double withdraw(Account ob,double amount) throws InsufficientFundException;
	public double deposit(Account ob,double amount);
	public boolean transferMoney(Account from,Account to,double amount);

}
