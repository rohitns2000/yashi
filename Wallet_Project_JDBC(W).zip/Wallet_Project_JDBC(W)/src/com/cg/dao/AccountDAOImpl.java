package com.cg.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.bean.Account;
public class AccountDAOImpl implements AccountDAO{

	@Override
	public boolean addAccount(Account ob) {
		Connection con=null;
		PreparedStatement selectSt = null;
		PreparedStatement updateSt = null;

	      try {
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="hr";
				String pass="hr";
				
				con = DriverManager.getConnection(url, user, pass);
				System.out.println("Connected Successfully!");
				con.setAutoCommit(false);
				int id = ob.getAid();
				selectSt = con.prepareStatement("Select * from account where aid =?");
				selectSt.setInt(1,ob.getAid());
				ResultSet rs = selectSt.executeQuery();
				while(rs.next())
				{
					if(id == rs.getInt("aid"))
					{System.out.println("Empoyee Already Exists!");}
				}
				updateSt = con.prepareStatement("insert into account values (?,?,?,?)");
				updateSt.setInt(1, ob.getAid());
				updateSt.setLong(2, ob.getMobile());
				updateSt.setString(3, ob.getAccountholder());
				updateSt.setDouble(4, ob.getBalance());
				int a = updateSt.executeUpdate();
				if(a!=1)
				{
					System.err.println("Empoyee not Added!!!");
					}
				}
	      catch(SQLException e)
	      {
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
				e.printStackTrace();
	      }
	    finally {
	      try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
	      
		return true;
	}

	@Override
	public boolean updateAccount(Account ob) {
		Connection con=null;
		PreparedStatement selectSt = null;
		PreparedStatement updateSt = null;

	      try {
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="hr";
				String pass="hr";
				
				con = DriverManager.getConnection(url, user, pass);
				System.out.println("Connected Successfully!");
				con.setAutoCommit(false);
				updateSt = con.prepareStatement("update account set aid =?,mobileno=?,accountholder=?,balance=? where mobileno=?");
				updateSt.setInt(1, ob.getAid());
				updateSt.setLong(2, ob.getMobile());
				updateSt.setString(3, ob.getAccountholder());
				updateSt.setDouble(4, ob.getBalance());
				updateSt.setLong(5, ob.getMobile());
				int a = updateSt.executeUpdate();
				if(a!=1)
				{
					System.err.println("Empoyee/Database not Updated!!!");
					}
				con.commit();
				}
	      catch(SQLException e)
	      {
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
				e.printStackTrace();
	      }
	    finally {
	      try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
		
		
		return true;
	}

	@Override
	public boolean deleteAccount(Long phone) {
		Connection con=null;
		PreparedStatement selectSt = null;
		PreparedStatement updateSt = null;

	      try {
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="hr";
				String pass="hr";
				
				con = DriverManager.getConnection(url, user, pass);
				System.out.println("Connected Successfully!");
				con.setAutoCommit(false);
				updateSt = con.prepareStatement("delete from account where mobileno=?");
				updateSt.setLong(1, phone);
				int a = updateSt.executeUpdate();
				if(a!=1)
				{
					System.err.println("Empoyee/Database not Updated!!!");
					}
				con.commit();
				}
	      catch(SQLException e)
	      {
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
				e.printStackTrace();
	      }
	    finally {
	      try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
		return true;
	}


	@Override
	public List< Account> getAllAccounts() {
		List<Account> lst = new ArrayList<Account>();
		
		Connection con=null;
		PreparedStatement selectSt = null;
		PreparedStatement updateSt = null;

	      try {
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="hr";
				String pass="hr";
				
				con = DriverManager.getConnection(url, user, pass);
				System.out.println("Connected Successfully!");
				
				con.setAutoCommit(false);
				selectSt = con.prepareStatement("Select * from account ");
				ResultSet rs = selectSt.executeQuery();
				while(rs.next())
				{
					int a_id = rs.getInt(1);
					long mobile=rs.getLong(2);
					String ah = rs.getString(3);
					double bal = rs.getDouble(4);
					Account ac = new Account(a_id,mobile,ah,bal);
					lst.add(ac);
				}
				con.commit();
				}
	      catch(SQLException e)
	      {
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
				e.printStackTrace();
	      }
	    finally {
	      try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
		
		return lst;
		
	}

	@Override
	public Account getAccount(Long mob) {
		Connection con=null;
		PreparedStatement selectSt = null;
		PreparedStatement updateSt = null;
		int a_id =0;long mobile=0L;String ah="";double bal=0.0;
	      try {
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="hr";
				String pass="hr";
				
				con = DriverManager.getConnection(url, user, pass);
				System.out.println("Connected Successfully!");
				
				con.setAutoCommit(false);
				selectSt = con.prepareStatement("Select * from account where mobileno=?");
				selectSt.setLong(1,mob);
				ResultSet rs = selectSt.executeQuery();
				while(rs.next())
				{
					a_id = rs.getInt(1);
					mobile=rs.getLong(2);
					ah = rs.getString(3);
					bal = rs.getDouble(4);
				}
				con.commit();
					
				}
	      catch(SQLException e)
	      {
				try {
					con.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState());
				e.printStackTrace();
	      }
	    finally {
	      try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    }
	  Account acc = new Account(a_id,mobile,ah,bal);
		
		return acc;
	}
	

}
